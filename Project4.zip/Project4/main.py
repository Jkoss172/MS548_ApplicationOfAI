# Jeffrey Koss
# Date: 07/16/2023
# Class: MS548
# Professor: Jill Coddington
# Assignment: Application of AI
# ETA: 3 hours

# It took me about 3 hours

from pytube import YouTube
from PIL import Image, ImageEnhance, ImageFilter
from sys import argv
import PyPDF2
import os
import sys


 

def youtube_downloader():
 #link = argv[1]
 yt = YouTube('https://youtu.be/OQdxibhdR_Y')
 print("Title: ", yt.title)
 print("View: ", yt.views)
 yd = yt.streams.get_highest_resolution()
 yd.download('D:\SchoolClasses\SoftwareEngineering\MS548AdvanceProgramming\Week 4\Homework\Project4\Downloaded Video')
 print("File Complete")
 main_menu()

def image_processor():
  path = "D:\SchoolClasses\SoftwareEngineering\MS548AdvanceProgramming\Week 4\Homework\Project4\Picture"
  pathOut = "D:\SchoolClasses\SoftwareEngineering\MS548AdvanceProgramming\Week 4\Homework\Project4\Picture"
  for filename in os.listdir(path):
    img = Image.open(f"{path}/{filename}")

    # sharpening, BW
    edit = img.filter(ImageFilter.SHARPEN).convert('L').rotate(-90)

    # contrast
    factor = 1.5
    enhancer = ImageEnhance.Contrast(edit)
    edit = enhancer.enhance(factor)

    # ADD MORE EDITS FROM DOCUMENTATION https://pillow.readthedocs.io/en/stable/

    clean_name = os.path.splitext(filename)[0]

    edit.save('D:\SchoolClasses\SoftwareEngineering\MS548AdvanceProgramming\Week 4\Homework\Project4\Picture\iguana.jpeg')

  

def pdf_merger():
 merger = PyPDF2.PdfMerger()

 for file in('D:\SchoolClasses\SoftwareEngineering\MS548AdvanceProgramming\Week 4\Homework\Project4\sample1.pdf', 'D:\SchoolClasses\SoftwareEngineering\MS548AdvanceProgramming\Week 4\Homework\Project4\sample2.pdf'):
   if file.endswith(".pdf"):
        merger.append(file)
   merger.write("D:\SchoolClasses\SoftwareEngineering\MS548AdvanceProgramming\Week 4\Homework\Project4\combined.pdf")
   

def quit_program():
  print("Good Bye!")
  exit()

def main_menu():
   print("Media Utility Program")
   print("\nChoose one: ")
   print("1. YouTube Downloader")
   print("2. Image Processor")
   print("3. PDF File Merger")
   print("4. Quit Program")
   choice = input("\nWhat is your choice: ")

   if choice == '1':
    youtube_downloader()
   elif choice == '2':
    image_processor()
   elif choice == '3':
    pdf_merger()
   elif choice == '4':
    quit_program()
   else:
    print("Try Again")
    main_menu()


main_menu()
